export default function App() {
  return <div style={{padding:20,fontSize:24}}>Paulina GPT is running!</div>
}
